from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os, httpx

app = FastAPI(title="Astra API", version="0.1.0")

class MorpheusConfig(BaseModel):
    base_url: str
    token: str

def morpheus_cfg() -> MorpheusConfig:
    return MorpheusConfig(
        base_url=os.getenv("MORPHEUS_URL", "").rstrip("/"),
        token=os.getenv("MORPHEUS_TOKEN", ""),
    )

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/morpheus/service-plans")
async def list_service_plans(max: int = 50, offset: int = 0):
    cfg = morpheus_cfg()
    if not (cfg.base_url and cfg.token):
        raise HTTPException(500, "Morpheus env vars not set")
    url = f"{cfg.base_url}/api/service-plans?max={max}&offset={offset}"
    async with httpx.AsyncClient(verify=False, timeout=30) as client:
        r = await client.get(url, headers={"Authorization": f"Bearer {cfg.token}"})
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text)
    return r.json()
