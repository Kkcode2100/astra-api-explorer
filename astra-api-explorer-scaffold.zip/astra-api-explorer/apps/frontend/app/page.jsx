"use client";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

export default function Home() {
  const [max] = useState(25);
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["service-plans", max],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/morpheus/service-plans?max=${max}`);
      if (!res.ok) throw new Error(await res.text());
      return res.json();
    }
  });

  return (
    <main style={{ padding: 24 }}>
      <h1 style={{ fontSize: 24, fontWeight: 700 }}>Astra — API Explorer & Integration Builder</h1>
      <p style={{ marginTop: 8 }}>Quick check: list Morpheus service plans (read-only).</p>
      <button onClick={() => refetch()} style={{ marginTop: 16, padding: "6px 10px" }}>
        Refresh
      </button>
      {isLoading && <p style={{ marginTop: 16 }}>Loading…</p>}
      {error && <pre style={{ marginTop: 16, color: "crimson" }}>{String(error)}</pre>}
      {data && (
        <pre style={{ marginTop: 16, maxHeight: "60vh", overflow: "auto", border: "1px solid #ddd", padding: 12, borderRadius: 6, background: "#fafafa" }}>
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </main>
  );
}
