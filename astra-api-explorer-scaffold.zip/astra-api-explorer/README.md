# Astra — API Explorer & Integration Builder (MVP Scaffold)

This is a minimal, runnable scaffold for an API Explorer + Integration Builder focused on HPE Morpheus.
It includes:
- FastAPI backend with a pass‑through endpoint to list Morpheus service plans
- Next.js frontend showing a quick read-only check
- Dockerfiles and docker-compose for a one-command run
- GitHub Actions CI skeleton

## Quick start

1) Copy `.env.example` to `.env` and set your Morpheus URL/token.
2) Build and run:
```bash
docker compose up --build
```
3) Open http://localhost:3000 and click **Refresh** to fetch Morpheus service plans.

## Structure
```
apps/
  backend/      # FastAPI service
  frontend/     # Next.js app
.github/workflows/ci.yml
docker-compose.yml
```

## Notes
- The backend disables TLS verification when calling Morpheus (verify=False) since many PoCs use self-signed certs.
  Switch to proper CA trust for production.
- Extend this scaffold with OAuth2/OIDC, secrets management, and full "Discover → Diff → Apply" flows.
